package com.kh.practice2.run;

import com.kh.practice2.func.CastingPractice;
public class Run {

	public static void main(String[] args) {
		
		CastingPractice c1 = new CastingPractice();
		//c1.test2();

		
		
		
	}

}
