package com.kh.operator;

public class Run {

	public static void main(String[] args) {
		//A_Arithmetic aa = new A_Arithmetic();
		//aa.method();
		
		B_InDecrease bi = new B_InDecrease();
		//bi.method1();
		//bi.method2();
		//bi.method3();
		//bi.method4();
		
		C_Compound cc = new C_Compound();
		//cc.method();
		
		D_LogicalNegation d1 = new D_LogicalNegation();
		//d1.method();
		
		E_Comparison ee = new E_Comparison();
		//ee.quiz();

		F_Logical f1 = new F_Logical();
		//f1.method4();
		
		G_Triple gt = new G_Triple();
		//gt.method6();
				
	}

}
//같은 패키지 안에서 불러올대는 import 안함