package com.kh.operator.practice.func;

import java.util.Scanner;

public class OperatorPractice {
	
	public void practice() {
		
		Scanner sc = new Scanner(System.in);
		System.out.print("인원 수 : ");
		int num = sc.nextInt();
		
		System.out.print("사탕 개수 : ");
		int candy = sc.nextInt();
		
		int a = candy / num;
		int b = candy % num;
		
		System.out.println("1인당 사탕 개수 " + a);
		System.out.println("남는 사탕 개수 " + b);
		
	}
	
	public void practice2() {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("이름 : ");
		String name = sc.nextLine();
		
		
		
		System.out.print("학년(숫자만) : ");
		int grade = sc.nextInt();
		
		System.out.print("반(숫자만) : ");
		int clas = sc.nextInt();
		
		System.out.print("번호(숫자만) : ");
		
		sc.nextLine();
		
		int num = sc.nextInt();
		
		System.out.print("성별(M/F) : ");
		char gender = sc.next().charAt(0);
		
		System.out.print("성적(소수점 아래 둘째자리까지) : ");
		double a = sc.nextDouble();
		
		String gender1 = (gender == 'M') ? "남" : "여";
		
		System.out.println(grade + "학년 " + clas + "반 " + num + "번 " + name +" " + gender1 + "학생의 성적은 " + a + "이다.");
		
	}
	
	public void practice3() {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("나이 :");
		int age = sc.nextInt();
		
		String result = age <= 13 ? "어린이" : age <= 19 ? "청소년":"성인";
		System.out.println(result);
		
	}
	
	public void practice5() {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("주민번호를 입력하세요(- 포함)");
		String res = sc.nextLine();
		
		char ch = res.charAt(7);
	
		String gender = (ch == '1' || ch == '3') ? "남자":"여자";
		
		System.out.println(gender);
		
	}
	
	public void practice6() {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("정수 1 : ");
		int num1 = sc.nextInt();
		
		System.out.print("정수 2 : ");
		int num2 = sc.nextInt();
		
		System.out.print("입력 : ");
		int input = sc.nextInt();
		
		boolean result = (input <= num1 || input > num2) ? true : false; 
		System.out.println(result);
		
	}
	
	public void practice7() {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("입력1 : ");
		int num1 = sc.nextInt();
		
		System.out.print("입력2 : ");
		int num2 = sc.nextInt();
		
		System.out.print("입력3 : ");
		int num3 = sc.nextInt();
		
		boolean result = (num1 == num2 && num2 == num3) ? true : false; 
		System.out.println(result);
		
	}
	
	public void practice8() {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("A사원의 연봉 : ");
		int a = sc.nextInt();
		double aBonus = a * 1.4;
		
		System.out.print("B사원의 연봉 : ");
		int b = sc.nextInt();
		
		
		System.out.print("C사원의 연봉 : ");
		int c = sc.nextInt();
		double cBonus = c * 1.15;
		
		
		
		System.out.printf("A사원 연봉/연봉+a : %d/%.1f \n", a , aBonus);
		System.out.println(aBonus > 3000 ? "3000 이상 " : "3000 미만");
		
		System.out.printf("B사원 연봉/연봉+a : %d/%.1f \n", b , (double)b);
		System.out.println(b > 3000 ? "3000 이상" : "3000 미만");
		
		System.out.printf("C사원 연봉/연봉+a : %d/%.13f \n", c , cBonus );
		System.out.println(cBonus > 3000 ? "3000이상" : "3000미만");
		
		
		
	}
	
}
