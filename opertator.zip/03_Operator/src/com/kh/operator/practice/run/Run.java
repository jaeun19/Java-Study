package com.kh.operator.practice.run;

import com.kh.operator.practice.func.*;


public class Run {
	public static void main(String[] args) {
	
	OperatorPractice aa = new OperatorPractice();
	
	//aa.practice8(); 
	
	
	
	}
}
